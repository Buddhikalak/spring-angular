/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.citypak.sandbox.model;

/**
 *
 * @author Buddhika Lakshan
 */
public class response {

    private String regionid;
    private String banglorename;
    private int idbanglore;

    /**
     * @return the regionid
     */
    public String getRegionid() {
        return regionid;
    }

    /**
     * @param regionid the regionid to set
     */
    public void setRegionid(String regionid) {
        this.regionid = regionid;
    }

    /**
     * @return the banglorename
     */
    public String getBanglorename() {
        return banglorename;
    }

    /**
     * @param banglorename the banglorename to set
     */
    public void setBanglorename(String banglorename) {
        this.banglorename = banglorename;
    }

    /**
     * @return the idbanglore
     */
    public int getIdbanglore() {
        return idbanglore;
    }

    /**
     * @param idbanglore the idbanglore to set
     */
    public void setIdbanglore(int idbanglore) {
        this.idbanglore = idbanglore;
    }

    
}
