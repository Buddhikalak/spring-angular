package com.citypak.sandbox.model;

public class banglore {
	int regionid;
	String banglorename;
	int idbanglore;
	public int getIdbanglore() {
		return idbanglore;
	}
	public void setIdbanglore(int idbanglore) {
		this.idbanglore = idbanglore;
	}
	public int getRegionid() {
		return regionid;
	}
	public void setRegionid(int regionid) {
		this.regionid = regionid;
	}
	public String getBanglorename() {
		return banglorename;
	}
	public void setBanglorename(String banglorename) {
		this.banglorename = banglorename;
	}
	
}
